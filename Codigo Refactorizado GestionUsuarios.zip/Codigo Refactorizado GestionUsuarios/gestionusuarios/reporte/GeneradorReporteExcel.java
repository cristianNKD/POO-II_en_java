package reporte;

public class GeneradorReporteExcel implements IGeneradorReporte {
    @Override
    public void generar() {
        System.out.println("Generando reporte en Excel");
    }
}
