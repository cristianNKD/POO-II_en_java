package reporte;

public interface IGeneradorReporte {
    void generar();
}
