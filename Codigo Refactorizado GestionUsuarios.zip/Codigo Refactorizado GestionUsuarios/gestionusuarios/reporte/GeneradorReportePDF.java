package reporte;

public class GeneradorReportePDF implements IGeneradorReporte {
    @Override
    public void generar() {
        System.out.println("Generando reporte en PDF");
    }
}
