package modelo;

public class Usuario {
    private String correo;

    public Usuario(String correo) {
        this.correo = correo;
    }

    public String getCorreo() {
        return correo;
    }
}
