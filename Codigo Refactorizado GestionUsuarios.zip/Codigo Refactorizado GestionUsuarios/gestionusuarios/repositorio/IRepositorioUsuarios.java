package repositorio;

import modelo.Usuario;

public interface IRepositorioUsuarios {
    void guardar(Usuario usuario);
}
