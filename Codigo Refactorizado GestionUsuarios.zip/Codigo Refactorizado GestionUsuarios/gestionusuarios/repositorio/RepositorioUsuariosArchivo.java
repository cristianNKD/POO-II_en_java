package repositorio;

import modelo.Usuario;

public class RepositorioUsuariosArchivo implements IRepositorioUsuarios {
    @Override
    public void guardar(Usuario usuario) {
        System.out.println("Guardando en archivo: " + usuario.getCorreo());
    }
}
