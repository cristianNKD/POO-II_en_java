package main;

import servicios.*;
import repositorio.*;
import reporte.*;

public class Main {
    public static void main(String[] args) {
        IValidadorCorreo validador = new ValidadorCorreo();
        IRepositorioUsuarios repositorio = new RepositorioUsuariosArchivo();
        IServicioCorreo correo = new ServicioCorreo();

        UsuarioService servicio = new UsuarioService(validador, repositorio, correo);

        servicio.agregarUsuario("juan@example.com");
        servicio.agregarUsuario("maria.example.com");

        servicio.generarReporte(new GeneradorReportePDF());
        servicio.generarReporte(new GeneradorReporteExcel());

        servicio.enviarCorreoBienvenida("ana@example.com");
        servicio.enviarCorreoBienvenida("anaexample.com");
    }
}
