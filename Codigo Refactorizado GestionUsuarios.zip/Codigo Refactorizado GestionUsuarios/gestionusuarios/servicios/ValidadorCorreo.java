package servicios;

public class ValidadorCorreo implements IValidadorCorreo {
    @Override
    public boolean esCorreoValido(String correo) {
        return correo != null && correo.contains("@");
    }
}
