package servicios;

public interface IValidadorCorreo {
    boolean esCorreoValido(String correo);
}
