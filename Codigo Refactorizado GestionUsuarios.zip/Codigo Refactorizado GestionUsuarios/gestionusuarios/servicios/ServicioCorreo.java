package servicios;

public class ServicioCorreo implements IServicioCorreo {
    @Override
    public void enviarCorreoBienvenida(String correo) {
        System.out.println("Enviando correo de bienvenida a: " + correo);
    }
}
