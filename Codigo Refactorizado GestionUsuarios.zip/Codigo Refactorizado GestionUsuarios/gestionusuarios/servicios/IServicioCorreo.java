package servicios;

public interface IServicioCorreo {
    void enviarCorreoBienvenida(String correo);
}
