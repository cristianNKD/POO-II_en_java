package servicios;

import modelo.Usuario;
import repositorio.IRepositorioUsuarios;
import reporte.IGeneradorReporte;

public class UsuarioService {
    private final IValidadorCorreo validadorCorreo;
    private final IRepositorioUsuarios repositorioUsuarios;
    private final IServicioCorreo servicioCorreo;

    public UsuarioService(IValidadorCorreo validadorCorreo,
                          IRepositorioUsuarios repositorioUsuarios,
                          IServicioCorreo servicioCorreo) {
        this.validadorCorreo = validadorCorreo;
        this.repositorioUsuarios = repositorioUsuarios;
        this.servicioCorreo = servicioCorreo;
    }

    public void agregarUsuario(String correo) {
        if (validadorCorreo.esCorreoValido(correo)) {
            Usuario usuario = new Usuario(correo);
            repositorioUsuarios.guardar(usuario);
            System.out.println("Usuario agregado: " + correo);
        } else {
            System.out.println("Correo inválido");
        }
    }

    public void enviarCorreoBienvenida(String correo) {
        if (validadorCorreo.esCorreoValido(correo)) {
            servicioCorreo.enviarCorreoBienvenida(correo);
        } else {
            System.out.println("Correo inválido");
        }
    }

    public void generarReporte(IGeneradorReporte generadorReporte) {
        generadorReporte.generar();
    }
}
