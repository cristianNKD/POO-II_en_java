class User:
    def __init__(self, id, email, password, last_login):
        self.id = id
        self.email = email
        self.password = password
        self.last_login = last_login
