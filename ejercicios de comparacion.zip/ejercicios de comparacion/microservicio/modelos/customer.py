from modelos.user import User

class Customer:
    def __init__(self, id, user: User, name, billing_address, default_shipping_address):
        self.id = id
        self.user = user
        self.name = name
        self.billing_address = billing_address
        self.default_shipping_address = default_shipping_address
