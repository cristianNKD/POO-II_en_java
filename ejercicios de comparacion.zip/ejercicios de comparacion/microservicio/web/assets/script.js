function agregar() {
    fetch('http://localhost:5000/customers', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            email: document.getElementById('email').value,
            password: document.getElementById('password').value,
            lastLogin: document.getElementById('lastLogin').value,
            name: document.getElementById('name').value,
            billingAddress: document.getElementById('billingAddress').value,
            defaultShippingAddress: document.getElementById('defaultShippingAddress').value
        })
    }).then(() => listar());
}

function listar() {
    fetch('http://localhost:5000/customers')
        .then(res => res.json())
        .then(data => {
            document.getElementById('lista').innerHTML =
                data.map(e => `<li>${e.name} (${e.user.email})</li>`).join('');
        });
}

listar();
