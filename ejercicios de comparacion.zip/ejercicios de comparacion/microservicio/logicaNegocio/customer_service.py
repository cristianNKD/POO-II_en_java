from accesoDatos.customer_dao import CustomerDAO
from modelos.customer import Customer
from modelos.user import User

class CustomerService:
    def __init__(self):
        self.dao = CustomerDAO()

    def obtener_todos(self):
        return self.dao.get_all()

    def crear_customer(self, data):
        user = User(None, data['email'], data['password'], data['lastLogin'])
        customer = Customer(None, user, data['name'], data['billingAddress'], data['defaultShippingAddress'])
        self.dao.insert(customer)
