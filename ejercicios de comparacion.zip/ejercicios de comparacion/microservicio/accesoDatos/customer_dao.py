import mysql.connector
from config import DB_CONFIG
from modelos.user import User
from modelos.customer import Customer

class CustomerDAO:
    def __init__(self):
        try:
            self.conn = mysql.connector.connect(**DB_CONFIG)
            print("✅ Conexión a la base de datos exitosa!")
        except mysql.connector.Error as err:
            print(f"❌ Error al conectar a la base de datos: {err}")
            self.conn = None

    def get_all(self):
        if not self.conn:
            print("⚠️ No hay conexión a la base de datos.")
            return []
        
        cursor = self.conn.cursor(dictionary=True)
        query = '''
            SELECT c.id AS customer_id, c.name, c.billingAddress, c.defaultShippingAddress,
                   u.id AS user_id, u.email, u.password, u.lastLogin
            FROM customers c
            JOIN users u ON c.user_id = u.id
        '''
        cursor.execute(query)
        results = cursor.fetchall()
        customers = []

        for r in results:
            user = User(r['user_id'], r['email'], r['password'], r['lastLogin'])
            customer = Customer(r['customer_id'], user, r['name'], r['billingAddress'], r['defaultShippingAddress'])
            customers.append(customer)

        cursor.close()
        return customers

    def insert(self, customer: Customer):
        if not self.conn:
            print("⚠️ No hay conexión a la base de datos.")
            return

        cursor = self.conn.cursor()

        user_query = "INSERT INTO users (email, password, lastLogin) VALUES (%s, %s, %s)"
        customer_query = '''
            INSERT INTO customers (id, name, billingAddress, defaultShippingAddress)
            VALUES (%s, %s, %s, %s)
        '''

        try:
            print("🔍 Ejecutando SQL para users:", user_query, (customer.user.email, customer.user.password, customer.user.last_login))
            cursor.execute(user_query, (customer.user.email, customer.user.password, customer.user.last_login))
            user_id = cursor.lastrowid

            print("🔍 Ejecutando SQL para customers:", customer_query, (user_id, customer.name, customer.billing_address, customer.default_shipping_address))
            cursor.execute(customer_query, (user_id, customer.name, customer.billing_address, customer.default_shipping_address))


            self.conn.commit()
            print("✅ Cliente insertado correctamente!")
        except mysql.connector.Error as err:
            print(f"❌ Error al insertar datos: {err}")
        finally:
            cursor.close()
