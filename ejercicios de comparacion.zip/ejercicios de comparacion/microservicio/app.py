from flask import Flask, jsonify, request
from flask_cors import CORS
from logicaNegocio.customer_service import CustomerService

app = Flask(__name__)
CORS(app)
servicio = CustomerService()

@app.route('/')
def home():
    return jsonify({'message': 'Bienvenido a la API de gestión de clientes'})

@app.route('/customers', methods=['GET'])
def get_customers():
    customers = servicio.obtener_todos()
    result = []
    for c in customers:
        result.append({
            'id': c.id,
            'name': c.name,
            'billingAddress': c.billing_address,
            'defaultShippingAddress': c.default_shipping_address,
            'user': {
                'id': c.user.id,
                'email': c.user.email,
                'lastLogin': c.user.last_login
            }
        })
    return jsonify(result)

@app.route('/customers', methods=['POST'])
def create_customer():
    data = request.get_json()
    print("Datos recibidos en la API:", data)  # <-- Verificar si los datos llegan correctamente
    servicio.crear_customer(data)
    return jsonify({'message': 'Cliente creado exitosamente'}), 201

if __name__ == '__main__':
    app.run(debug=True)
