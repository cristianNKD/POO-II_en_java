public class Persona {
    protected String nombre;
    protected String email;
}
