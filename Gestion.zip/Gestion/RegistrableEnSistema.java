public interface RegistrableEnSistema{
    void registrableEnSistema();
}