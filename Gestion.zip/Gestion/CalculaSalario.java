public interface CalculaSalario {
    void calcularSalario();
}
