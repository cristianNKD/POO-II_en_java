public class ClienteExterno extends Persona implements RegistrableEnSistema {
    private String sector;
    @Override
    public void registrableEnSistema(){
        System.out.println("Cliente externo registrado en el sistema.");
    }
}
