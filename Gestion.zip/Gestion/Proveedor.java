public class Proveedor extends Persona implements RegistrableEnSistema {
    private String empresa;
    @Override
    public void registrableEnSistema(){
        System.out.println("Proveedor registrado en sistema.");
    }
}
