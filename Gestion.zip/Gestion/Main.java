public class Main {
    public static void main(String[] args) {
        Empleado empleado = new Empleado();
        empleado.registrableEnSistema();
        empleado.calcularSalario();
        Proveedor proveedor = new Proveedor();
        proveedor.registrableEnSistema();
        ClienteExterno cliente = new ClienteExterno();
        cliente.registrableEnSistema();
    }
}
