public class Empleado extends Persona implements RegistrableEnSistema, CalculaSalario {
    private String cargo;
    @Override
    public void registrableEnSistema(){
        System.out.println("Empleado registrado con credenciales.");
    }
    @Override
    public void calcularSalario(){
        System.out.println("Salario base: $3000");
    }
}
