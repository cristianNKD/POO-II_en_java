public class Suma extends Operacion {
    // En esta se va a usar herencia como tambien las demas execpto el main wey pendejo men 
    // Lo heredan de operacion wey revise el codigo despues para comprender mejor este codigo y los pilares de la programacion xd
    public Suma(double numeroUno, double numeroDos){
        super(numeroUno, numeroDos);
    }
    @Override
    public double calcular(){
        return numeroUno+ numeroDos;
    }

}
