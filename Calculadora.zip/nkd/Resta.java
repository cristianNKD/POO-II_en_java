public class Resta  extends Operacion{
    public Resta(double numeroUno, double numeroDos){
        super(numeroUno, numeroDos);

    }
    @Override
    public double calcular(){
        return numeroUno - numeroDos;
        
    }
    
}
