public abstract class Operacion{
    protected double numeroUno;
    protected double numeroDos;
    public Operacion(double numeroUno, double numeroDos){
        this.numeroUno= numeroUno;
        this.numeroDos=numeroDos;
    }
    public abstract double calcular();// wey aqui se usa el polimorfismos donde se sobrescribio la clase en una subclase 
} 