public class Division extends Operacion{
    public Division(double numeroUno, double numeroDos){
        super ( numeroUno, numeroDos);
    }
    @Override
    public double calcular(){
        return numeroUno/ numeroDos;
    }
    
}
