
import java.util.Scanner;

public class Main{
    public static void main(String[] args) {
        Calculadora calculadora = new Calculadora();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite el primer numero: ");
        double nUno = scanner.nextDouble();
        System.out.println("Digite el segundo numero: ");
        double nDos= scanner.nextDouble();
        System.out.println("Elija que operacion desea: (+, -, *, /)");
        char operacion = scanner.next().charAt(0);
        Operacion op;
        switch(operacion){
            case'+':
              op = new Suma(nUno, nDos);
              break;
            case '-':
              op = new Resta(nUno, nDos);
              break;
            case '*':
              op = new Multiplicacion(nUno, nDos);
              break;
            case '/':
              op = new Division(nUno, nDos);
              break;
            default:
              System.out.println("Operacion denegada");
              return;
            
        }
        double resultado = calculadora.ejecutarOperacion(op);
        System.out.println("resultado: "+ resultado);
    }
}
