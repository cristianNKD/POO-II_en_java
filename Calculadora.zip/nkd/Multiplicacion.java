public class Multiplicacion extends Operacion{
    public Multiplicacion(double numeroUno, double numeroDos){
        super(numeroUno, numeroDos);
    }
    @Override
    public double calcular(){
        return numeroUno * numeroDos;
    }
    
}
