import java.util.*;

public class Main {
    private static ProductoManager productoManager = new ProductoManager();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            mostrarMenu();
            int opcion = leerEntero("Seleccione una opción: ");
            if (!procesarOpcion(opcion)) break;
        }
    }

    private static void mostrarMenu() {
        System.out.println("1. Agregar producto");
        System.out.println("2. Ver productos");
        System.out.println("3. Buscar producto");
        System.out.println("4. Eliminar producto");
        System.out.println("5. Salir");
    }

    private static boolean procesarOpcion(int opcion) {
        switch (opcion) {
            case 1:
                agregarProducto();
                break;
            case 2:
                mostrarProductos();
                break;
            case 3:
                buscarProducto();
                break;
            case 4:
                eliminarProducto();
                break;
            case 5:
                System.out.println("Hasta luego");
                return false;
            default:
                System.out.println("Opción inválida");
        }
        return true;
    }
    

    private static void agregarProducto() {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        double precio = leerDouble("Precio: ");
        System.out.print("Categoría: ");
        String categoria = scanner.nextLine();
        productoManager.agregarProducto(nombre, precio, categoria);
        System.out.println("Producto agregado.");
    }

    private static void mostrarProductos() {
        for (Producto p : productoManager.obtenerTodosLosProductos()) {
            System.out.println(p.getId() + " - " + p.getNombre() + " $" + p.getPrecio() + " [" + p.getCategoria() + "]");
        }
    }

    private static void buscarProducto() {
        int id = leerEntero("ID: ");
        Producto p = productoManager.buscarProductoPorId(id);
        if (p != null) {
            System.out.println(p.getNombre() + " $" + p.getPrecio());
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    private static void eliminarProducto() {
        int id = leerEntero("ID: ");
        if (productoManager.eliminarProductoPorId(id)) {
            System.out.println("Producto eliminado.");
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un número entero.");
            }
        }
    }

    private static double leerDouble(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un número decimal.");
            }
        }
    }
}
