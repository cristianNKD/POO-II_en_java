import java.util.*;

public class ProductoManager {
    private Map<Integer, Producto> productos = new HashMap<>();
    private int ultimoId = 0;

    public void agregarProducto(String nombre, double precio, String categoria) {
        Producto producto = new Producto(ultimoId++, nombre, precio, categoria);
        productos.put(producto.getId(), producto);
    }

    public Collection<Producto> obtenerTodosLosProductos() {
        return productos.values();
    }

    public Producto buscarProductoPorId(int id) {
        return productos.get(id);
    }

    public boolean eliminarProductoPorId(int id) {
        return productos.remove(id) != null;
    }
}
